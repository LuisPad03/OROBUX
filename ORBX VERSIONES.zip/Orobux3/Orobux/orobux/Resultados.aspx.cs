﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using FlexCel.XlsAdapter;
using FlexCel.Core;
using FlexCel.Report;
using FlexCel.Render;
using System.IO;
using System.Web.UI.DataVisualization.Charting;

public partial class orobux_Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["id_usuario"] == null) Response.Redirect("../Inicio/Default.aspx");
        if (!IsPostBack)
        {
            int id_usuario;
            id_usuario = int.Parse(Session["id_usuario"].ToString());
            Session["id_usuario"] = id_usuario;
            Carga_resultado(id_usuario, 0);
            lbl_usuario.Text = Session["nombre"].ToString();
            //lbl_inteligencia_emocional.Text = string.Format("{0:dd/MM/yyyy HH:mm}", DateTime.Now);
        }
    }

    private void Carga_resultado(int id_usuario, int id_cuestionario)
    {
        Cuestionario Da = new Cuestionario();
        Da.id_usuario = id_usuario;
        DataSet Ds = new DataSet();

        Ds = Da.Carga_criterio(id_cuestionario, 1);
        Resultados.DataSource = Ds;
        Resultados.DataBind();
        /*grd_resultados.DataSource = Ds;
        grd_resultados.DataBind();
        BindChartBar(Ds.Tables[0]); */
    }
    private void BindChartBar(DataTable dt, Chart Chart1, string Titulo)
    {
        DataTable dsChartData = new DataTable();
        StringBuilder strScript = new StringBuilder();
        dsChartData = dt;
        try
        {
            // Set series chart type
            //Chart1.Series["Series1"].ChartType = SeriesChartType.Column;
            //Chart1.Series["Series2"].ChartType = SeriesChartType.Column;
            //Chart1.ChartAreas["ChartArea1"].AxisX.LabelStyle.IsEndLabelVisible = true;
            // Chart1.ChartAreas["ChartArea2"].AxisX.LabelStyle.IsEndLabelVisible = true;

            Chart1.Titles[0].Text = Titulo;
            Chart1.Legends[0].Title = "Calificacion";
            Chart1.Legends[1].Title = "Referencia";



            // Set series point width ancho de la columna
            Chart1.Series["Series1"]["PointWidth"] = "0.6";
            Chart1.Series["Series2"]["PointWidth"] = "0.6";


            // Show data points labels puntuacion
            Chart1.Series["Series1"].IsValueShownAsLabel = true;
            Chart1.Series["Series2"].IsValueShownAsLabel = true;


            // Set data points label style
            //Chart1.Series["Series1"]["BarLabelStyle"] = "Center";
            //Chart1.Series["Series2"]["BarLabelStyle"] = "Center";

            Chart1.ChartAreas[0].AxisX.LabelStyle.Angle = 45;
            // Draw as 3D Cylinder
            Chart1.Series["Series1"]["DrawingStyle"] = "Cylinder";
            Chart1.Series["Series2"]["DrawingStyle"] = "Cylinder";

            //DataView firstView = new DataView(dt);
            //Series series = new Series();
            //series.Name = "Series1";
            //DataPoint points = new DataPoint();
            //Series series2 = new Series();
            //series.Name = "Series2";
            //DataPoint points2 = new DataPoint();
            //int i = 0;
            foreach (DataRow dr in dt.Rows)
            {
                Chart1.Series["Series1"].Points.AddXY("Calficacion", double.Parse(dr["Calficacion"].ToString()));
                Chart1.Series["Series2"].Points.AddXY("Referencia", double.Parse(dr["Referencia"].ToString()));


            }


        }
        catch (Exception e)
        {

        }
    }
    private void BindChartBar2(DataTable dt, Chart Chart1)
    {
        DataTable dsChartData = new DataTable();
        StringBuilder strScript = new StringBuilder();
        dsChartData = dt;
        try
        {

            Chart1.Series["Default"].ChartType = SeriesChartType.Bar;

            // Show as 3D
            Chart1.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;

            // Draw as 3D Cylinder
            Chart1.Series["Default"]["DrawingStyle"] = "Cylinder";

            DataView firstView = new DataView(dt);

            // Since the DataView implements IEnumerable, pass the dataview directly into
            //   the DataBind method with the name of the Columns selected in the query    
            Chart1.Series["Default"].Points.DataBindXY(firstView, "Calficacion", firstView, "Referencia");
            
            /* dsChartData = dt;

             strScript.Append(@"<script type='text/javascript'>  
                     google.load('visualization', '1', {packages: ['corechart']});</script>  

                     <script type='text/javascript'>  
                     function drawVisualization() {         
                     var data = google.visualization.arrayToDataTable([  
                     ['Fecha','Calificaion','Referencia'],");

             foreach (DataRow row in dsChartData.Rows)
             {
                 strScript.Append("['" + row["Clave"].ToString().Trim() + "'," + row["Calficacion"].ToString().Trim() + "," + row["Referencia"].ToString().Trim() + "],");
             }
             strScript.Remove(strScript.Length - 1, 1);
             strScript.Append("]);");

             strScript.Append("var options = { title : '', vAxis: {title: ''},  hAxis: {title: 'Criterios', slantedTextAngle: 90}, seriesType: 'bars', series: {2: {type: 'bars'}} };");
             strScript.Append(" var chart = new google.visualization.ComboChart(document.getElementById('BarChart'));  chart.draw(data, options); var image = '<img src=\"' + chart.getImageURI() + '\">'; $('#imgPDF').click(function() {$(\"input[name=chart_data]\").val(chart.getImageURI());}); } google.setOnLoadCallback(drawVisualization);");
             strScript.Append(" </script>");

              ltBarChart.Text = strScript.ToString();*/
        }
        catch (Exception e)
        {

        }
    }

    private void Reporte()
    {

        string CarpetaDestinoArchivo = Server.MapPath("~") + "/Informes/";
        string NombreFinal = "resultados.pdf", destinoReporte = CarpetaDestinoArchivo + NombreFinal;
        if (File.Exists(CarpetaDestinoArchivo + NombreFinal)) File.Delete(CarpetaDestinoArchivo + NombreFinal);
        string Archivo = CarpetaDestinoArchivo + "Reporte_resltado.xls";
        XlsFile xls = new FlexCel.XlsAdapter.XlsFile(Archivo);
        DataTable firstTable = new DataTable();
        //DataTable SecondTable = new DataTable();
        //int producto = 0;
        //int Cantidad = 0;
        using (FlexCelPdfExport pdf = new FlexCelPdfExport(xls, true))
        {


            using (FileStream pdfstream = new FileStream(CarpetaDestinoArchivo + NombreFinal, FileMode.Create))
            {
                pdf.BeginExport(pdfstream);
                pdf.Workbook = xls;


                xls = new FlexCel.XlsAdapter.XlsFile(Archivo);
                pdf.Workbook = xls;

                DataSet ds = new DataSet();
                /*oData.DataBase = BasedeDatos;
                oData.Sentencia = "sp_consulta_resultado '" + Session["id_usuario"].ToString() + "'";
                oData.GetData(ref ds);*/
                Cuestionario Da = new Cuestionario();
                Da.id_usuario = int.Parse(Session["id_usuario"].ToString());
                DataSet Ds = new DataSet();
                ds = Da.Carga_resultado();
                //Da = null;

                firstTable = ds.Tables[0];
                // SecondTable = ds.Tables[1];
                //DataRow row = (DataRow)firstTable.Rows[firstTable.Rows.Count - 1];
                //producto = Convert.ToInt16(row["Numero"]);

                //foreach (DataRow item in firstTable.Rows)
                //{
                //    Cantidad += Convert.ToInt16(item["CantidadSolicitada"]);
                //}



                using (FlexCelReport fr = new FlexCelReport(true))
                {
                    //xls.SetCellValue(2, 6, "*" + tkt + "*"); //Barras Incidencia
                    //xls.SetCellValue(3, 4, producto);
                    //xls.SetCellValue(4, 4, Cantidad);
                    xls.ActiveSheetByName = "IE";
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        int iLinea = 4;
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            xls.SetCellValue(iLinea, 7, int.Parse(dr["Calficacion"].ToString()));
                            xls.SetCellValue(iLinea, 8, int.Parse(dr["Referencia"].ToString()));
                            iLinea += 1;
                        }
                        //fr.AddTable("Resultado", ds.Tables[0]);

                        //fr.Run(xls);

                        pdf.ExportSheet(1, -1);

                    }
                    Da.id_cuestionario = 2;
                    ds = Da.Carga_resultado();

                    xls.ActiveSheetByName = "MI";
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        int iLinea = 4;
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            xls.SetCellValue(iLinea, 7, int.Parse(dr["Calficacion"].ToString()));
                            xls.SetCellValue(iLinea, 8, int.Parse(dr["Referencia"].ToString()));
                            iLinea += 1;
                        }
                        //fr.AddTable("Resultado", ds.Tables[0]);

                       // fr.Run(xls);

                        pdf.ExportSheet(2, -1);

                    }
                    Da.id_cuestionario = 3;
                    ds = Da.Carga_resultado();

                    xls.ActiveSheetByName = "SR";
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        int iLinea = 4;
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            xls.SetCellValue(iLinea, 7, int.Parse(dr["Calficacion"].ToString()));
                            xls.SetCellValue(iLinea, 8, int.Parse(dr["Referencia"].ToString()));
                            iLinea += 1;
                        }
                        //fr.AddTable("Resultado", ds.Tables[0]);

                        // fr.Run(xls);

                        pdf.ExportSheet(3, -1);

                    }
                    Da.id_cuestionario = 4;
                    ds = Da.Carga_resultado();

                    xls.ActiveSheetByName = "IM";
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        int iLinea = 4;
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            xls.SetCellValue(iLinea, 7, int.Parse(dr["Calficacion"].ToString()));
                            xls.SetCellValue(iLinea, 8, int.Parse(dr["Referencia"].ToString()));
                            iLinea += 1;
                        }
                        //fr.AddTable("Resultado", ds.Tables[0]);

                        // fr.Run(xls);

                        pdf.ExportSheet(4, -1);

                    }
                    Da.id_cuestionario = 5;
                    ds = Da.Carga_resultado();

                    xls.ActiveSheetByName = "AM";
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        int iLinea = 4;
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            xls.SetCellValue(iLinea, 7, int.Parse(dr["Calficacion"].ToString()));
                            xls.SetCellValue(iLinea, 8, int.Parse(dr["Referencia"].ToString()));
                            iLinea += 1;
                        }
                        //fr.AddTable("Resultado", ds.Tables[0]);

                        // fr.Run(xls);

                        pdf.ExportSheet(5, -1);

                    }

                }

                pdf.EndExport();
            }

        }
        DescargarArchivo(CarpetaDestinoArchivo + NombreFinal);

    }
    public void DescargarArchivo(string ruta)
    {
        try
        {
            String fName = ruta;
            FileInfo fi = new FileInfo(fName);
            long sz = fi.Length;
            Response.ClearContent();
            Response.ContentType = MimeType(System.IO.Path.GetExtension(fName));
            Response.AddHeader("Content-Disposition", string.Format("attachment; filename = {0}", System.IO.Path.GetFileName(fName)));
            Response.AddHeader("Content-Length", sz.ToString("F0"));
            Response.TransmitFile(fName);
            Response.End();
        }
        catch (Exception e)
        {
            string err = e.Message;
        }
    }
    public static string MimeType(string Extension)
    {
        string mime = "application/octetstream";
        if (string.IsNullOrEmpty(Extension))
            return mime;
        string ext = Extension.ToLower();
        Microsoft.Win32.RegistryKey rk = Microsoft.Win32.Registry.ClassesRoot.OpenSubKey(ext);
        if (rk != null && rk.GetValue("Content Type") != null)
            mime = rk.GetValue("Content Type").ToString();
        return mime;
    }
    protected void btn_reporte_Click(object sender, EventArgs e)
    {
        Reporte();
    }

    protected void Resultados_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        RepeaterItem item = e.Item;
        if (item.ItemType == ListItemType.AlternatingItem || item.ItemType == ListItemType.Item)
        {
            Repeater nota = (Repeater)item.FindControl("nota");
            int id_usuario = int.Parse(Session["id_usuario"].ToString());
            Cuestionario Da = new Cuestionario();
            Da.id_usuario = id_usuario;
            DataSet Ds = new DataSet();

            Ds = Da.Carga_criterio(int.Parse(((System.Data.DataRowView)(item.DataItem)).Row.ItemArray[0].ToString()), 2);// int.Parse(((System.Data.DataRowView)(item.DataItem)).Row.ItemArray[0].ToString()));
            nota.DataSource = Ds;
            nota.DataBind();
            DataGrid grd_resultados= (DataGrid) item.FindControl("grd_resultados");
            Da.id_cuestionario = int.Parse(((System.Data.DataRowView)(item.DataItem)).Row.ItemArray[0].ToString());
            Da.id_usuario = id_usuario;
            Ds = Da.Carga_resultado();
            grd_resultados.DataSource = Ds;
            grd_resultados.DataBind();
            Chart grafica = (Chart)item.FindControl("Chart1");
            BindChartBar(Ds.Tables[0], grafica, ((System.Data.DataRowView)(item.DataItem)).Row.ItemArray[1].ToString() );
            //lbl_id_pregunta.Text = ((System.Data.DataRowView)(item.DataItem)).Row.ItemArray[0].ToString();
        }
    }

}