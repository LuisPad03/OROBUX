﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Web.UI.DataVisualization.Charting;


public partial class PRUEBA : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Cuestionario Da = new Cuestionario();
        Da.id_usuario = 2;
        Da.id_cuestionario = 1;
        DataSet Ds = new DataSet();
        Ds = Da.Carga_resultado();
        BindChartBar(Ds.Tables[0], Chart1);
    }
    private void BindChartBar(DataTable dt, Chart Chart1)
    {
        DataTable dsChartData = new DataTable();
        StringBuilder strScript = new StringBuilder();
        dsChartData = dt;
        try
        {
            // Set series chart type
            //Chart1.Series["Series1"].ChartType = SeriesChartType.Column;
            //Chart1.Series["Series2"].ChartType = SeriesChartType.Column;
            //Chart1.ChartAreas["ChartArea1"].AxisX.LabelStyle.IsEndLabelVisible = true;
            // Chart1.ChartAreas["ChartArea2"].AxisX.LabelStyle.IsEndLabelVisible = true;

            Chart1.Titles[0].Text = "Cuestionario 1";
            Chart1.Legends[0].Title = "Calificacion";
            Chart1.Legends[1].Title = "Referencia";



            // Set series point width ancho de la columna
            Chart1.Series["Series1"]["PointWidth"] = "0.6";
            Chart1.Series["Series2"]["PointWidth"] = "0.6";


            // Show data points labels puntuacion
            Chart1.Series["Series1"].IsValueShownAsLabel = true;
            Chart1.Series["Series2"].IsValueShownAsLabel = true;


            // Set data points label style
            //Chart1.Series["Series1"]["BarLabelStyle"] = "Center";
            //Chart1.Series["Series2"]["BarLabelStyle"] = "Center";

            Chart1.ChartAreas[0].AxisX.LabelStyle.Angle = 45;
            // Draw as 3D Cylinder
            Chart1.Series["Series1"]["DrawingStyle"] = "Cylinder";
            Chart1.Series["Series2"]["DrawingStyle"] = "Cylinder";

            //DataView firstView = new DataView(dt);
            //Series series = new Series();
            //series.Name = "Series1";
            //DataPoint points = new DataPoint();
            //Series series2 = new Series();
            //series.Name = "Series2";
            //DataPoint points2 = new DataPoint();
            //int i = 0;
            foreach (DataRow dr in dt.Rows)
            {
                Chart1.Series["Series1"].Points.AddXY("Calficacion", double.Parse(dr["Calficacion"].ToString()));
                Chart1.Series["Series2"].Points.AddXY("Referencia", double.Parse(dr["Referencia"].ToString()));


            }

    
        }
        catch (Exception e)
        {

        }
    }
}